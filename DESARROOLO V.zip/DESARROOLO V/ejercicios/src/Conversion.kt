fun main(args: Array<String>) {

    val i: Int = 1
    val l: Long = i.toLong()

    val s: String = i.toString()

    println(s)
}