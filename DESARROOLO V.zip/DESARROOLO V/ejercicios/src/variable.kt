
fun main(args: Array<String>){
    var titulo = "The Good Code"
    var subtitulo: String

    subtitulo = "Academia online"

    println("Titulo: " + titulo)
    println("Subtitulo: " + subtitulo)
}