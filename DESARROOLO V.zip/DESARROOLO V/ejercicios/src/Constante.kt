
const val x=2
const val titulo="the good code"

fun main(args: Array<String>){
    println(titulo)
    //no se puede
    //titulo=hola
}