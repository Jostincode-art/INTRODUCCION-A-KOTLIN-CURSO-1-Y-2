fun main(args: Array<String>) {
    var operando1: Int
    var operando2: Int

    operando1 = 5
    operando2 = 10

    println("Suma = " + sumaInt(operando1, operando2))
}

fun sumaInt(op1: Int, op2: Int): Int {
    return op1 + op2
}
